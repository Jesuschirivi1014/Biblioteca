class libro:
    def _init_(self, titulo, autor, genero, num_paginas):
        self.titulo = titulo
        self.autor = autor
        self.genero = genero
        self.num_paginas = num_paginas
        
    def mostrar_info(self):
        print("Titulo:", self.titulo)
        print("Autor:", self.autor)
        print("Genero:", self.genero)
        print("Numero de paginas:", self.numero_paginas)
        
class libroprestado(libro):
    def _init_(self, titulo, autor, genero, num_paginas, prestado_a):
        super()._init_(titulo, autor, genero, num_paginas)
        self.prestado_a = prestado_a
    
    def mostrar_info(self):
        super().mostrar_info()
        print("Prestado a:", self.prestado_a)
        
# Crear objetos de la clase libro
libro1 = libro("El codigo Da vinci", "Dan Brown", "Misterio", 624)
libro2 = libro("Cien años de soledad", "Gabriel garica marquez", "Realismo Magico", 432)

#Mostrar informacion de los libros
print("Informacion del libro 1:")
libro1.mostrar_info()
print("Informacion del libro 2:")
libro2.mostrar_info()

#Crear objetos de la clase Libroprestado
libro_prestado1 = libroprestado("python crash  course", "Eric mattles", "progamacion", 544, "Juan perez")
libro_prestado2 = libroprestado("clean code", "Robert c. Martin", "progamacion", 464, "Marin Gomez")

#Mostrar informacion de los libros prestados
print("\nInformacion del libro prestado 1:")
libro_prestado1.mostrar_info()
print("\nInformacion del libro prestado 2:")
libro_prestado2.mostrar_info()